# Tempo — cały kod strony

Plik `index.html` zawiera cały HTML, CSS i JavaScript opublikowanej strony.

## Uruchomienie

Otwórz `index.html` w przeglądarce. Nie trzeba instalować żadnych pakietów ani uruchamiać serwera.

## Edycja

- Wygląd: sekcje `<style>`.
- Treść i formularz: elementy HTML z nazwami `tempo-…`.
- Zestawy ćwiczeń: obiekt `examples` w sekcji `<script>`.
- Obsługa formularza: funkcja `generatePlan`.
- Wyświetlanie planu i dni tygodnia: funkcja `renderPlan`.

Plan jest przykładowy. Zestawy ćwiczeń zależą od celu i doświadczenia; BMI jest wyświetlane jako informacja i samo nie określa intensywności treningu.

Formularz działa lokalnie w przeglądarce i nie wysyła wpisanych danych do zewnętrznego API. Strona zawiera ikony Lucide osadzone bezpośrednio w kodzie.
